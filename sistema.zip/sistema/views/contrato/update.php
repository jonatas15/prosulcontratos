<?php

?>
<div class="col-md-12">
<div class="contrato-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
</div>
